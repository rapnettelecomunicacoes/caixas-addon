<?php
// === CONFIGURAÇÃO INICIAL ===
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__FILE__) . '/error.log');

// === VERIFICAÇÃO DE SESSÃO ===
session_name('mka');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// === VERIFICAÇÃO DE AUTENTICAÇÃO (COMPATÍVEL COM MÚLTIPLAS VERSÕES) ===
// Aceita várias formas de validar autenticação entre diferentes versões do mkauth
$autenticado = false;

// Verificar diferentes possíveis variáveis de sessão
if (isset($_SESSION['mka_logado']) || 
    isset($_SESSION['MKA_Logado']) || 
    isset($_SESSION['logado']) ||
    isset($_SESSION['Logado']) ||
    isset($_SESSION['user_id']) ||
    isset($_SESSION['usuario']) ||
    isset($_SESSION['admin'])) {
    $autenticado = true;
}

// Se não conseguir validar via SESSION, tenta via headers customizados
if (!$autenticado && isset($_SERVER['HTTP_X_AUTHENTICATED']) && $_SERVER['HTTP_X_AUTHENTICATED'] == '1') {
    $autenticado = true;
}

// Se ainda não autenticado, redireciona
if (!$autenticado) {
    header("Location: ../../");
    exit();
}

// === CARREGAR DEPENDÊNCIAS ===
$addon_base = dirname(__FILE__);
require_once $addon_base . '/addons.class.php';

// === VALIDAR LICENÇA ===
// Desativado para compatibilidade cross-servidor
// if (file_exists($addon_base . "/src/LicenseMiddleware.php")) {
//     require_once $addon_base . "/src/LicenseMiddleware.php";
//     $middleware = new LicenseMiddleware();
//     $status = $middleware->getStatus();
//     if (!$status["instalada"] || (isset($status["expirada"]) && $status["expirada"])) {
//         header("Location: src/license_install.php");
//         exit;
//     }
// }

// === CONTROLAR ROTEAMENTO ===
$route = isset($_GET['_route']) ? $_GET['_route'] : '';

// === INCLUIR APLICAÇÃO SE HOUVER ROTA ===
if (!empty($route) && in_array($route, ['inicio', 'adicionar', 'editar', 'backup', 'maps', 'mapadeclientes', 'mapadectos', 'configurar'])) {
    $app_file = $addon_base . '/src/cto/componente/' . $route . '/index.php';
    if (file_exists($app_file)) {
        include_once $app_file;
        exit();
    }
}

// === RENDERIZAR DASHBOARD PADRÃO ===
?>
