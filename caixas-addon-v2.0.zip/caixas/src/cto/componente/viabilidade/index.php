<?php
// Redirecionar para a view
include_once dirname(__FILE__) . '/viabilidade.view.php';
?>
