<?php
/**
 * Configuração de Banco de Dados
 * Database Configuration
 */

// Credenciais do Banco de Dados
$Host = 'localhost';
$user = 'root';
$pass = 'vertrigo';
$db_name = 'mkradius';
$table_name = 'mp_caixa';

// Socket Unix para conexão local (MariaDB/MySQL)
$socket = '/var/run/mysqld/mysqld.sock';

// Verifica se o socket existe, caso contrário usa TCP
if (!file_exists($socket)) {
    $socket = null;
}
